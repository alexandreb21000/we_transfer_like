<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/wetransfert.css">
    <title>We transfert</title>
</head>
<body onload="depart();">

        <header class="h10vh bgblack clrwhite d_flexcenter">
            <p>We transfert</p>
        </header>
        
            
        <section class="d_flexcenter row h80vh">

            <p class="fs100">UPLOAD REUSSI</p>


        </section>

 
        <footer class="h10vh bgblack clrwhite d_flexcenter">
            <p> lien lien lien lien</p>
        </footer>

    <script type="text/javascript" src="js/wetransfert.js"> </script>
</body>
</html>