document.getElementById('submit').addEventListener('click',function(){
    console.log('passe');
var essai = setTimeout(retour,1000);
})



//function retour(){
//clearTimeout(essai);
//    console.log('retour');

//    var xhttp = new XMLHttpRequest();
//    xhttp.onreadystatechange = function() {
//      if (this.readyState == 4 && this.status == 200) {
//        document.getElementById("ajax").innerHTML =
//        this.responseText;
//      }
//    };
//    xhttp.open("GET", "test.php", true);
//    xhttp.send();
//}

// #region Formulaire
var $firstButton = $(".first"),
    $secondButton = $(".second"),
    $input = $("input"),
    $name = $(".name"),
    $more = $(".more"),
    $yourname = $(".yourname"),
    $reset = $(".reset"),
    $ctr = $(".container");

$firstButton.on("click", function (e) {
    $(this).text("Saving...").delay(900).queue(function () {
        $ctr.addClass("center slider-two-active").removeClass("full slider-one-active");
    });
    e.preventDefault();
});

$secondButton.on("click", function (e) {
    $(this).text("Saving...").delay(900).queue(function () {
        $ctr.addClass("full slider-three-active").removeClass("center slider-two-active slider-one-active");
        $name = $name.val();
        if ($name == "") {
            $yourname.html("Anonymous!");
        }
        else { $yourname.html($name + "!"); }
    });
    e.preventDefault();
});

//// copy
//balapaCop("Step by Step Form", "#999");
// #endregion Formulaire