﻿<?php
$serveur ="localhost";
$login = "root";
$pass = "";
try{
$connexion = new PDO("mysql:host=$serveur;dbname=wetransfert",$login, $pass);
$connexion -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
if(isset($_POST['mailUploader'])){
$mailUploader = $_POST['mailUploader'];
}
if(isset($_FILES['fichierUpload']['tmp_name'])){
$content_dir = 'dossier/'; // dossier où sera déplacé le fichier
$tmp_file = $_FILES['fichierUpload']['tmp_name'];
if( !is_uploaded_file($tmp_file) )
{
exit("Le fichier est introuvable");
}
// on copie le fichier dans le dossier de destination
$name_file = $_FILES['fichierUpload']['name'];
if( !move_uploaded_file($tmp_file, $content_dir . $name_file) )
{
exit("Impossible de copier le fichier dans $content_dir");
}
$imgExt = substr($_FILES['fichierUpload']['name'], strrpos($_FILES['fichierUpload']['name'], '.') + 1);
$imgName = $_FILES['fichierUpload']['name'];
$fichierUpload = $imgName;
}
$dateUpload = date('d-m-Y-G-i');
$stmt = $connexion->prepare("INSERT INTO Upload(fichierUpload,mailUploader,dateUpload) VALUES (:fichierUpload,:mailUploader,:dateUpload)");
$stmt->setFetchMode(PDO::FETCH_ASSOC);
$stmt->bindParam(':fichierUpload',$fichierUpload);
$stmt->bindParam(':mailUploader',$mailUploader);
$stmt->bindParam(':dateUpload',$dateUpload);
$stmt->execute();
}
catch(PDOException $e) {
echo"echec : ".$e -> getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>LAIKA Transfert</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/wetransfert.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

    <style>

        /* NOTE: The styles were added inline because Prefixfree needs access to your styles and they must be inlined if they are on local disk! */
        @import url(https://fonts.googleapis.com/css?family=Roboto:400,300);
        @import url(https://fonts.googleapis.com/css?family=Pacifico);

        input:focus,
        button:focus {
            outline: none;
        }

        button:hover,
        .reset:hover {
            opacity: .8;
        }

        button:active,
        .reset:active {
            opacity: .5;
        }

        .container {
            width: 400px;
            position: absolute;
            top: 50%;
            left: 50%;
            -webkit-transform: translate(-50%, -50%);
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
        }

        .steps {
            margin-bottom: 10px;
            position: relative;
            height: 25px;
        }

            .steps > div {
                position: absolute;
                top: 0;
                -webkit-transform: translate(-50%);
                -ms-transform: translate(-50%);
                transform: translate(-50%);
                height: 25px;
                padding: 0 5px;
                ;
                display: inline-block;
                width: 80px;
                text-align: center;
                -webkit-transition: .3s all ease;
                transition: .3s all ease;
            }

                .steps > div > span {
                    line-height: 25px;
                    height: 25px;
                    margin: 0;
                    color: #777;
                    font-family: 'Roboto', sans-serif;
                    font-size: .9rem;
                    font-weight: 300;
                }

                .steps > div > .liner {
                    position: absolute;
                    height: 2px;
                    width: 0%;
                    left: 0;
                    top: 50%;
                    margin-top: -1px;
                    background: #999;
                    -webkit-transition: .3s all ease;
                    transition: .3s all ease;
                }

        .step-one {
            left: 0;
        }

        .step-two {
            left: 33%;
            clip: rect(0, 0px, 25px, 0px);
        }

        .step-three {
            left: 66%;
            clip: rect(0, 0px, 25px, 0px);
        }

        .step-four {
            left: 100%;
            clip: rect(0, 0px, 25px, 0px);
        }

        .line {
            width: 100%;
            height: 5px;
            background: #ddd;
            position: relative;
            border-radius: 10px;
            overflow: visible;
            margin-bottom: 50px;
        }

            .line .dot-move {
                position: absolute;
                top: 50%;
                left: 0%;
                width: 15px;
                height: 15px;
                -webkit-transform: translate(-50%, -50%);
                -ms-transform: translate(-50%, -50%);
                transform: translate(-50%, -50%);
                background: #ddd;
                border-radius: 50%;
                -webkit-transition: .3s all ease;
                transition: .3s all ease;
            }

            .line .dot {
                position: absolute;
                top: 50%;
                width: 15px;
                height: 15px;
                left: 0;
                background: #ddd;
                border-radius: 50%;
                -webkit-transition: .3s all ease;
                transition: .3s all ease;
                -webkit-transform: translate(-50%, -50%) scale(.5);
                -ms-transform: translate(-50%, -50%) scale(.5);
                transform: translate(-50%, -50%) scale(.5);
            }

                .line .dot.zero {
                    left: 0%;
                    background: #bbb;
                }

        .container.slider-one-active .dot.zero {
            background: #5892fc;
        }

        .line .dot.center {
            left: 33%;
            background: #bbb
        }

        .line .dot.full {
            left: 66%;
            background: #bbb
        }

        .line .dot.recipient {
            left: 100%;
            background: #bbb
        }

        .slider-ctr {
            width: 100%;
            overflow: hidden;
        }

        .slider {
            overflow: hidden;
            width: 1200px;
            -webkit-transition: .3s all ease;
            transition: .3s all ease;
            -webkit-transform: translate(0px) scale(1);
            -ms-transform: translate(0px) scale(1);
            transform: translate(0px) scale(1);
        }

        .container.slider-one-active .slider-two,
        .container.slider-one-active .slider-three
        .container.slider-one-active .slider-four {
            -webkit-transform: scale(.5);
            -ms-transform: scale(.5);
            transform: scale(.5);
        }



        .container.slider-two-active .slider-one,
        .container.slider-two-active .slider-three
        .container.slider-two-active .slider-four {
            -webkit-transform: scale(.5);
            -ms-transform: scale(.5);
            transform: scale(.5);
        }

        /*.container.slider-two-active .slider-one,
        .container.slider-two-active .slider-three,
        .container.slider-two-active .slider-four
        {
            -webkit-transform: scale(.5);
            -ms-transform: scale(.5);
            transform: scale(.5);
        }*/

        .container.slider-three-active .slider-one,
        .container.slider-three-active .slider-two
        .container.slider-three-active .slider-four {
            -webkit-transform: scale(.5);
            -ms-transform: scale(.5);
            transform: scale(.5);
        }

        .container.slider-four-active .slider-one,
        .container.slider-four-active .slider-two
        .container.slider-four-active .slider-three {
            -webkit-transform: scale(.5);
            -ms-transform: scale(.5);
            transform: scale(.5);
        }
        .slider-one,
        .slider-two,
        .slider-three,
        .slider-four {
            -webkit-transition: .3s all ease;
            transition: .3s all ease;
        }

        .slider-form {
            float: left;
            width: 400px;
            text-align: center;
        }

            .slider-form h2 {
                font-size: 1.5rem;
                font-family: 'Roboto', sans-serif;
                font-weight: 300;
                margin-bottom: 50px;
                color: #999;
                position: relative;
            }

                .slider-form h2 .yourname {
                    font-weight: 400;
                }

            .slider-form h3 {
                font-size: 1.5rem;
                font-family: 'Roboto', sans-serif;
                font-weight: 300;
                margin-bottom: 50px;
                line-height: 1.5;
                color: #999;
                position: relative;
            }

                .slider-form h3 .balapa {
                    font-family: 'Pacifico', sans-serif;
                    display: inline-block;
                    color: #5892fc;
                    text-decoration: none
                }

            .slider-form [type="text"] {
                width: 100%;
                box-sizing: border-box;
                padding: 15px 20px;
                background: #fafafa;
                border: 1px solid transparent;
                color: #777;
                border-radius: 50px;
                margin-bottom: 50px;
                font-size: 1rem;
                font-family: 'Roboto', sans-serif;
                position: relative;
                z-index: 99;
            }

                .slider-form [type="text"]:focus {
                    background: #fcfcfc;
                    border: 1px solid #ddd;
                }

            .slider-form button,
            .reset {
                display: inline-block;
                text-decoration: none;
                background: #5892fc;
                border: none;
                color: white;
                padding: 10px 25px;
                font-size: 1rem;
                border-radius: 3px;
                cursor: pointer;
                font-family: 'Roboto', sans-serif;
                font-weight: 300;
                position: relative;
            }

        /*  emot */

        /*.label-ctr {
            margin-bottom: 50px;
        }

        label.radio {
            height: 55px;
            width: 55px;
            display: inline-block;
            margin: 0 10px;
            background: transparent;
            position: relative;
            border-radius: 50%;
            cursor: pointer
        }

            label.radio input {
                visibility: hidden
            }

                label.radio input:checked + .emot {
                    -webkit-transform: scale(1.25);
                    -ms-transform: scale(1.25);
                    transform: scale(1.25);
                }

                    label.radio input:checked + .emot,
                    label.radio input:checked + .emot .mouth {
                        border-color: #5892fc;
                    }

                        label.radio input:checked + .emot:before,
                        label.radio input:checked + .emot:after {
                            background: #5892fc;
                        }

            label.radio .emot {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: #fafafa;
                border-radius: 50%;
                border: 2px solid #ddd;
                -webkit-transition: .3s all ease;
                transition: .3s all ease;
            }

                label.radio .emot:before {
                    content: "";
                    position: absolute;
                    top: 15px;
                    left: 15px;
                    width: 5px;
                    height: 10px;
                    background: #ddd;
                }

                label.radio .emot:after {
                    content: "";
                    position: absolute;
                    top: 15px;
                    right: 15px;
                    width: 5px;
                    height: 10px;
                    background: #ddd;
                }

                label.radio .emot .mouth {
                    position: absolute;
                    bottom: 10px;
                    right: 15px;
                    left: 15px;
                    height: 15px;
                    border-radius: 50%;
                    border: 3px solid #ddd;
                    background: transparent;
                    clip: rect(0, 35px, 10px, 0);
                }

                    label.radio .emot .mouth.smile {
                        -webkit-transform: rotate(180deg);
                        -ms-transform: rotate(180deg);
                        transform: rotate(180deg);
                    }

                    label.radio .emot .mouth.sad {
                        -webkit-transform: translateY(50%);
                        -ms-transform: translateY(50%);
                        transform: translateY(50%);
                    }*/

        /*	center */

        .container.center .line .dot-move {
            left: 33%;
            -webkit-animation: .3s anim 1;
        }

        .container.center .line .dot.center {
            background: #5892fc;
        }

        .container.center .slider {
            -webkit-transform: translate(-400px);
            -ms-transform: translate(-400px);
            transform: translate(-400px);
        }

        .container.center .step-two {
            clip: rect(0, 100px, 25px, 0px);
        }

        .container.center .step-one .liner {
            width: 100%;
        }

        /*	full */

        .container.full .line .dot-move {
            left: 66%;
            -webkit-animation: .3s anim 1;
        }

        .container.full .line .dot.full {
            background: #5892fc;
        }

        .container.full .slider {
            -webkit-transform: translate(-800px);
            -ms-transform: translate(-800px);
            transform: translate(-800px);
        }

        .container.full .step-two,
        .container.full .step-three {
            clip: rect(0, 100px, 25px, 0px);
        }

            .container.full .step-one .liner,
            .container.full .step-two .liner {
                width: 100%;
            }

        /*	recipient */

        .container.recipient .line .dot-move {
            left: 100%;
            -webkit-animation: .3s anim 1;
        }

        .container.recipient .line .dot.recipient {
            background: #5892fc;
        }

        .container.recipient .slider {
            -webkit-transform: translate(-800px);
            -ms-transform: translate(-800px);
            transform: translate(-800px);
        }

        .container.recipient .step-two,
        .container.recipient .step-three {
            clip: rect(0, 100px, 25px, 0px);
        }

            .container.recipient .step-one .liner,
            .container.recipient .step-two .liner,
            .container.recipient .step-three .liner
            {
                width: 100%;
            }
    </style>
    <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>-->
</head>
<body>
    <div class="container slider-one-active">
        <div class="steps">
            <div class="step step-one">
                <div class="liner"></div>
                <span>Hello!</span>
            </div>
            <div class="step step-two">
                <div class="liner"></div>
                <span>Rating</span>
            </div>
            <div class="step step-three">
                <div class="liner"></div>
                <span>recipient</span>
            </div>
            <div class="step step-four">
                <div class="liner"></div>
                <span>Conclusion</span>
            </div>
        </div>
        <div class="line">
            <div class="dot-move"></div>
            <div class="dot zero"></div>
            <div class="dot center"></div>
            <div class="dot full"></div>
            <div class="dot recipient"></div>
        </div>
        <div class="slider-ctr">
            <div class="slider">
                <form class="slider-form slider-one">
                    <h2>Your name</h2>
                    <label class="input">
                        <input type="text" class="name" placeholder="What's your name?">
                    </label>
                    <button class="first next">Next Step</button>
                </form>
                <form class="slider-form slider-two">
                    <h2>Your Mail</h2>
                    <label class="input">
                        <input type="text" class="name" placeholder="What's your mail?">
                    </label>
                    <button class="second next">Next Step</button>
                </form>
                <form class="slider-form slider-three">
                    <h2>Recipient Mail</h2>
                    <label class="input">
                        <input type="text" class="name" placeholder="What's recipient mail?">
                    </label>
                    <button class="third next">Next Step</button>
                </form>
                <form class="slider-form slider-four">
                    <h2>Hello, <span class="yourname"></span></h2>
                    <h3>
                        Thank you for your input!
                    </h3>
                    <a class="reset" href="#" target="_blank">Reset</a>
                </form>

            </div>
        </div>
        </div>
        <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
        <!--<script src='https://codepen.io/balapa/pen/c58fffe58d661ae3d4b168a43eb3b2b8.js'></script>-->

        <script src="js/index.js"></script>
        <script type="text/javascript" src="js/wetransfert.js"></script>


</body>
</html>
